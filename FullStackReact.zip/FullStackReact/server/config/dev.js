// dev.js cont commit tghis
module.exports = {
	googleClientID: '197435937826-92q8jp55vrk3g1dvmjq7elbe2qf0567h.apps.googleusercontent.com',
	googleClientSecret: 'L8bf4BzYI_a6luWvZb3kj4fd',
	mongoURI:'mongodb://admin:admin@ds113169.mlab.com:13169/emaily',
	cookieKey: 'ihfkjasdhfjaushfjaurngakeurgkaeurhgkaeuhrgkaerhg',

};
