const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mongoose = require('mongoose');
const keys = require('../config/keys');

const User = mongoose.model('users');

passport.serializeUser((user, done) => {
  // this is the id from mongo mlabs not the profile id
  done(null, user.id);
});
passport.deserializeUser((id, done) => {
  User.findById(id).then(user => {
    done(null, user);
  });
});

passport.use(
    new GoogleStrategy(
        {
            clientID: keys.googleClientID,
            clientSecret: keys.googleClientSecret,
            callbackURL: '/auth/google/callback',
            proxy:true
        },
        (accessToken, refreshToken, profile, done) => {
          User.findOne({googleId: profile.id })
          .then((existingUser) => {
             if(existingUser){
               // if we already have a record with the given Profile ID
               done(null, existingUser);
             } else{
               //we dibt gave a user recird wuth this ID, make a new one
               new User({googleId: profile.id }).save()
               .then(user => done (null, user));
             }
          })

        }
    )
);
